// Este arquivo é gerado automaticamente pelo GitHub Actions a partir do API_URL.txt.
// Para testar no PC sem API, abra index.html?mock=1
window.API_URL = 'MOCK';
