// Guarda o app no aparelho para abrir mesmo sem sinal.
// Estratégia: tenta a rede primeiro (para receber atualizações); sem rede, usa a cópia guardada.
const CACHE = 'checklist-cogera-v1';
const ARQS = ['./', 'index.html', 'config.js', 'logo.png', 'icon-192.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARQS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;                       // chamadas da API (POST) nunca passam pelo cache
  const url = new URL(req.url);
  if (url.hostname.includes('script.google') || url.hostname.includes('googleusercontent')) return;
  if (url.pathname.endsWith('.apk')) return;
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 5000);
      const res = await fetch(req, { signal: ctl.signal });
      clearTimeout(t);
      if (res.ok || res.type === 'opaque') cache.put(req.mode === 'navigate' ? 'index.html' : req, res.clone());
      return res;
    } catch (err) {
      const hit = await cache.match(req.mode === 'navigate' ? 'index.html' : req, { ignoreSearch: true });
      if (hit) return hit;
      throw err;
    }
  })());
});
