// API SIMULADA – só para testar o app sem a planilha (abra index.html?mock=1&u=gestor  ou  &u=tec1).
// Imita o Code.gs: mesmas ações, mesmas regras. Os dados ficam no navegador (localStorage).
(function () {
  const K = 'mock_ck_db_v3';
  const now = () => new Date().toISOString();
  const id = p => p + Math.random().toString(36).slice(2, 12);
  let db = null;
  try { db = JSON.parse(localStorage.getItem(K)); } catch (e) {}
  const salvar = () => { try { localStorage.setItem(K, JSON.stringify(db)); } catch (e) {} };
  const fotosB64 = {};

  function seed() {
    db = { usuarios: [], modelos: [], os: [], equips: [], resp: {}, fotos: [], clientes: [], seq: 0 };
    db.usuarios.push({ id: 'U1', nome: 'Leonardo (gestor)', perfil: 'Gestor', token: 'gestor', ativo: true, telefone: '' });
    db.usuarios.push({ id: 'U2', nome: 'Carlos Souza', perfil: 'Técnico', token: 'tec1', ativo: true, telefone: '67999990001' });
    db.usuarios.push({ id: 'U3', nome: 'Marcos Lima', perfil: 'Técnico', token: 'tec2', ativo: true, telefone: '' });
    const M = (nome, cat, itens) => db.modelos.push({ id: id('M'), nome, categoria: cat, itens: itens.map((i, k) => ({ id: id('I'), etapa: i[0], ordemEtapa: i[1], titulo: i[2], tipo: i[3], minFotos: i[3] === 'FOTO' ? (i[4] || 1) : 0, unidade: i[5] || '', obrig: i[8] === false ? false : i[3] !== 'OBS', instr: i[9] || '', par: i[6] || '', tag: i[7] || '' })) });
    M('Transformador a óleo', 'Subestação', [
      ['Antes', 1, 'Vista geral do transformador', 'FOTO', 2, '', 'P1'], ['Antes', 1, 'Placa de identificação', 'FOTO', 1, '', '', 'PLACA'],
      ['Antes', 1, 'Nível de óleo', 'OKNOK'], ['Testes', 2, 'Megôhmetro – resistência de isolamento', 'FOTO', 6],
      ['Testes', 2, 'Isolamento AT-massa', 'NUMERO', 0, 'MΩ'], ['Depois', 3, 'Vista geral do transformador', 'FOTO', 2, '', 'P1'], ['Depois', 3, 'Observações finais', 'OBS']]);
    M('Posto de transformação – escopo visual', 'Rede', [
      ['Antes', 1, 'Vista geral do posto', 'FOTO', 1, '', 'P1'], ['Antes', 1, 'Integridade do poste', 'OKNOK'], ['Depois', 2, 'Vista geral do posto', 'FOTO', 1, '', 'P1']]);
    M('TOF em gerador', 'Geradores', [['Antes', 1, 'Placa do gerador', 'FOTO', 1, '', '', 'PLACA'], ['Testes', 2, 'Tensão de saída', 'NUMERO', 0, 'V'], ['Testes', 2, 'Partida em vazio', 'OKNOK']]);
    M('Disjuntor', 'Subestação', [['Antes', 1, 'Vista geral do disjuntor', 'FOTO', 1, '', 'P1'], ['Testes', 2, 'Abertura e fechamento', 'OKNOK'], ['Depois', 3, 'Vista geral do disjuntor', 'FOTO', 1, '', 'P1']]);
    M('Banco de capacitores', 'Subestação', [['Antes', 1, 'Vista geral do banco', 'FOTO', 1], ['Testes', 2, 'Fusíveis', 'OKNOK']]);
    M('Aceite do cliente', 'Encerramento', [['Encerramento', 1, 'Observações do cliente', 'OBS'], ['Encerramento', 1, 'Assinatura do responsável', 'ASSINATURA']]);
    M('Diário de obra', 'Obras', [
      ['Dados do dia', 1, 'Tempo – manhã', 'ESCOLHA', 0, 'Bom;Nublado;Chuva'], ['Dados do dia', 1, 'Condição de trabalho', 'ESCOLHA', 0, 'Praticável;Parcialmente;Impraticável'],
      ['Equipe', 2, 'Equipe presente (nome e função)', 'TEXTO', 0, '', '', '', true, 'Um por linha. Ex.: João Silva – eletricista'], ['Equipe', 2, 'Total de pessoas na obra', 'NUMERO', 0, 'pessoas'],
      ['Equipe', 2, 'Foto da equipe / DDS', 'FOTO', 1], ['Atividades', 3, 'Atividades executadas no dia', 'TEXTO'], ['Atividades', 3, 'Fotos do andamento', 'FOTO', 2],
      ['Ocorrências', 4, 'Houve ocorrência, paralisação ou acidente?', 'ESCOLHA', 0, 'Não;Sim'], ['Ocorrências', 4, 'Fotos da ocorrência', 'FOTO', 1, '', '', '', false],
      ['Encerramento', 5, 'Assinatura do encarregado', 'ASSINATURA']]);
    const mid = n => db.modelos.find(m => m.nome === n).id;
    db.clientes.push({ id: 'C1', nome: 'Cliente 123 (exemplo)', local: 'Campo Grande - MS', contato: '', telefone: '', obs: '', setores: [
      { id: 'S1', nome: 'Banco de Capacitor', checklists: [{ modeloId: mid('Banco de capacitores'), nome: 'Banco 1' }] },
      { id: 'S2', nome: 'Subestação 1', checklists: [{ modeloId: mid('Transformador a óleo'), nome: 'Trafo 1' }, { modeloId: mid('Disjuntor'), nome: 'Disjuntor geral' }] },
      { id: 'S3', nome: 'Encerramento', checklists: [{ modeloId: mid('Aceite do cliente'), nome: 'Aceite' }] }] });
    // uma OS já enviada ao tec1
    const o = { id: 'OS1', numero: 'OS-0001', cliente: 'Energisa MS', local: 'SE Centro – Campo Grande', data: now().slice(0, 10), tecnicos: ['U2'], status: 'Enviada', obs: 'Levar megôhmetro e TTR.', criadaEm: now(), atualizadaEm: now(), enviadaEm: now(), finalizadaEm: '' };
    db.os.push(o); db.seq = 1;
    db.equips.push({ id: 'E1', osId: 'OS1', ordem: 1, modeloId: db.modelos[1].id, modeloNome: db.modelos[1].nome, nome: 'Posto 1', itens: JSON.parse(JSON.stringify(db.modelos[1].itens)) });
    db.equips.push({ id: 'E2', osId: 'OS1', ordem: 2, modeloId: db.modelos[2].id, modeloNome: db.modelos[2].nome, nome: 'Gerador 150 kVA', itens: JSON.parse(JSON.stringify(db.modelos[2].itens)) });
    const ap = { id: 'OS0', numero: 'OS-0000', cliente: 'Energisa MS', local: 'SE Norte', data: '2026-10-28', tecnicos: ['U2'], status: 'Aprovada', obs: '', criadaEm: now(), atualizadaEm: now(), enviadaEm: now(), finalizadaEm: '2026-10-30T15:00:00Z' };
    db.os.push(ap);
    db.equips.push({ id: 'E0', osId: 'OS0', ordem: 1, modeloId: db.modelos[2].id, modeloNome: db.modelos[2].nome, nome: 'Gerador 80 kVA', setor: '', itens: JSON.parse(JSON.stringify(db.modelos[2].itens)) });
    salvar();
  }
  if (!db) seed();

  const EDIT = ['Enviada', 'Em campo', 'Devolvida'];
  const obrig = i => i.tipo !== 'OBS' && i.obrig !== false;
  function completo(i, r, n) {
    if (i.tipo === 'FOTO') return i.obrig === false || n >= (+i.minFotos || 1);
    if (i.tipo === 'ASSINATURA') return i.obrig === false || n >= 1;
    if (i.tipo === 'OBS' || i.obrig === false) return true;
    if (!r || !r.valor) return false;
    if (i.tipo === 'OKNOK' && r.valor === 'NOK' && !String(r.obs || '').trim()) return false;
    return true;
  }
  function detalhe(o) {
    const resp = {}; Object.values(db.resp).filter(r => r.osId === o.id).forEach(r => resp[r.k] = { valor: r.valor, obs: r.obs, status: r.status, comentario: r.comentario, por: r.por, em: r.em });
    return {
      ...o, tecnicosNomes: o.tecnicos.map(t => (db.usuarios.find(u => u.id === t) || {}).nome || t), pastaUrl: '',
      equips: db.equips.filter(e => e.osId === o.id).sort((a, b) => a.ordem - b.ordem).map(e => ({ id: e.id, nome: e.nome, setor: e.setor || '', modeloId: e.modeloId, modeloNome: e.modeloNome, itens: e.itens })),
      respostas: resp, fotos: db.fotos.filter(f => f.osId === o.id && !f.removida).map(f => ({ id: f.id, equipId: f.equipId, itemId: f.itemId, etapa: f.etapa, driveId: f.driveId, nome: f.nome, dataHora: f.dataHora, lat: f.lat, lng: f.lng, acc: f.acc || '', tecnico: f.tecnico }))
    };
  }
  function pend(o) {
    const d = detalhe(o), faltas = [];
    d.equips.forEach(e => e.itens.forEach(i => {
      const r = d.respostas[e.id + '|' + i.id];
      const n = d.fotos.filter(f => f.equipId === e.id && f.itemId === i.id).length;
      if (r && r.status === 'DEVOLVIDO') faltas.push(e.nome + ' › ' + i.titulo + ' (devolvido)');
      else if (!completo(i, r, n)) faltas.push(e.nome + ' › ' + i.titulo);
    }));
    return faltas;
  }
  const meu = (o, u) => u.perfil === 'Gestor' || o.tecnicos.includes(u.id);

  const A = {
    whoami: (a, u) => ({ id: u.id, nome: u.nome, perfil: u.perfil }),
    myOS: (a, u) => db.os.filter(o => o.tecnicos.includes(u.id) && [...EDIT, 'Para validar', 'Aprovada'].includes(o.status)).map(detalhe),
    saveRespostas(a, u) {
      let n = 0;
      (a.itens || []).forEach(it => {
        const o = db.os.find(x => x.id === it.osId); if (!o || !meu(o, u) || !EDIT.includes(o.status)) return;
        const k = it.equipId + '|' + it.itemId, r = db.resp[k];
        if (r && r.status === 'APROVADO') return;
        if (r && it.ts && String(r.em) > String(it.ts)) return;
        db.resp[k] = { k, osId: it.osId, equipId: it.equipId, itemId: it.itemId, valor: String(it.valor ?? ''), obs: String(it.obs ?? ''), status: 'RESPONDIDO', comentario: r ? r.comentario : '', por: u.nome, em: it.ts || now() };
        if (o.status === 'Enviada') o.status = 'Em campo';
        n++;
      });
      salvar(); return { salvos: n };
    },
    uploadFoto(a, u) {
      const ex = db.fotos.find(f => f.id === a.fotoId); if (ex) return { fotoId: ex.id, driveId: ex.driveId, repetida: true };
      const o = db.os.find(x => x.id === a.osId); if (!o) throw new Error('OS não encontrada');
      if (!meu(o, u)) throw new Error('OS não é sua');
      if (!EDIT.includes(o.status)) throw new Error('OS não está aberta para fotos (' + o.status + ')');
      const e = db.equips.find(x => x.id === a.equipId); const it = e && e.itens.find(i => i.id === a.itemId);
      if (!it) throw new Error('Item não encontrado');
      const n = db.fotos.filter(f => f.equipId === a.equipId && f.itemId === a.itemId).length + 1;
      const f = { id: a.fotoId, osId: a.osId, equipId: a.equipId, itemId: a.itemId, etapa: it.etapa, driveId: 'mock-' + a.fotoId, nome: it.titulo + '_' + n + '.jpg', dataHora: a.dataHora, lat: a.lat, lng: a.lng, acc: a.acc || '', tecnico: u.nome, removida: false };
      db.fotos.push(f); fotosB64[f.id] = a.b64;
      try { localStorage.setItem('mock_foto_' + f.id, a.b64); } catch (e2) {}
      if (o.status === 'Enviada') o.status = 'Em campo';
      salvar(); return { fotoId: f.id, driveId: f.driveId };
    },
    removeFoto(a, u) { const f = db.fotos.find(x => x.id === a.fotoId); if (f) f.removida = true; salvar(); return { removida: !!f }; },
    submitOS(a, u) {
      const o = db.os.find(x => x.id === a.osId); if (!o) throw new Error('OS não encontrada');
      if (o.status === 'Para validar') return { status: o.status };
      if (!EDIT.includes(o.status)) throw new Error('OS está ' + o.status);
      const f = pend(o); if (f.length) throw new Error('Ainda falta: ' + f.slice(0, 5).join('; '));
      o.status = 'Para validar'; o.atualizadaEm = now(); salvar(); return { status: o.status };
    },
    getFoto(a) {
      const b = fotosB64[a.fotoId] || localStorage.getItem('mock_foto_' + a.fotoId);
      if (!b) throw new Error('Foto não encontrada');
      return { b64: b, nome: 'foto.jpg' };
    },
    listUsuarios: () => db.usuarios.map(u => ({ ...u })),
    saveUsuario(a, u) {
      if (!String(a.nome || '').trim()) throw new Error('Informe o nome');
      let r = db.usuarios.find(x => x.id === a.id);
      if (r) { if (r.id === u.id && (a.ativo === false || a.perfil !== 'Gestor')) throw new Error('Você não pode desativar o seu próprio acesso de gestor'); Object.assign(r, { nome: a.nome, perfil: a.perfil, telefone: a.telefone, ativo: a.ativo !== false }); if (a.novoToken) r.token = id('t'); }
      else { r = { id: id('U'), nome: a.nome, perfil: a.perfil, telefone: a.telefone, ativo: true, token: id('t') }; db.usuarios.push(r); }
      salvar(); return { id: r.id };
    },
    listModelos: () => JSON.parse(JSON.stringify(db.modelos)),
    saveModelo(a) {
      const m = a.modelo; if (!m.nome.trim()) throw new Error('Informe o nome');
      const itens = m.itens.map((i, k) => ({ id: i.id || id('I'), etapa: i.etapa, ordemEtapa: i.ordemEtapa, titulo: i.titulo, tipo: i.tipo, minFotos: i.tipo === 'FOTO' ? Math.max(1, +i.minFotos || 1) : 0, unidade: i.unidade || '', obrig: i.obrig !== false, instr: i.instr || '', par: i.par || '', tag: i.tag || '' }));
      let r = db.modelos.find(x => x.id === m.id);
      if (r) Object.assign(r, { nome: m.nome, categoria: m.categoria, itens }); else { r = { id: id('M'), nome: m.nome, categoria: m.categoria, itens }; db.modelos.push(r); }
      salvar(); return { id: r.id };
    },
    deleteModelo(a) { db.modelos = db.modelos.filter(m => m.id !== a.id); salvar(); return { ok: true }; },
    listOS() {
      return db.os.map(o => {
        const d = detalhe(o); let total = 0, feitos = 0, ap = 0, dv = 0;
        d.equips.forEach(e => e.itens.forEach(i => {
          if (!obrig(i)) return; total++;
          const r = d.respostas[e.id + '|' + i.id];
          if (completo(i, r, d.fotos.filter(f => f.equipId === e.id && f.itemId === i.id).length)) feitos++;
          if (r && r.status === 'APROVADO') ap++; if (r && r.status === 'DEVOLVIDO') dv++;
        }));
        return { id: o.id, numero: o.numero, cliente: o.cliente, local: o.local, data: o.data, tecnicos: o.tecnicos, status: o.status, atualizadaEm: o.atualizadaEm, equips: d.equips.map(e => (e.setor ? e.setor + ' › ' : '') + e.nome), total, feitos, aprovados: ap, devolvidos: dv, fotos: d.fotos.length };
      });
    },
    getOS(a) { const o = db.os.find(x => x.id === a.id); if (!o) throw new Error('OS não encontrada'); return detalhe(o); },
    saveOS(a, u) {
      const d = a.os; if (!String(d.cliente || '').trim()) throw new Error('Informe o cliente');
      let o = db.os.find(x => x.id === d.id);
      if (!o) { db.seq++; o = { id: id('OS'), numero: 'OS-' + String(db.seq).padStart(4, '0'), status: 'Rascunho', criadaEm: now(), enviadaEm: '', finalizadaEm: '' }; db.os.push(o); }
      Object.assign(o, { cliente: d.cliente, clienteId: d.clienteId || '', local: d.local, data: d.data, obs: d.obs, tecnicos: d.tecnicos || [], atualizadaEm: now() });
      const manter = new Set();
      (d.equips || []).forEach((e, k) => {
        const ex = e.id && db.equips.find(x => x.id === e.id);
        if (ex) { ex.ordem = k + 1; ex.nome = e.nome || ex.nome; ex.setor = e.setor || ''; manter.add(ex.id); return; }
        const m = db.modelos.find(x => x.id === e.modeloId); if (!m) throw new Error('Modelo não encontrado');
        const ne = { id: id('E'), osId: o.id, ordem: k + 1, modeloId: m.id, modeloNome: m.nome, nome: e.nome || m.nome, setor: e.setor || '', itens: JSON.parse(JSON.stringify(m.itens)) };
        db.equips.push(ne); manter.add(ne.id);
      });
      db.equips = db.equips.filter(e => e.osId !== o.id || manter.has(e.id));
      salvar(); return { id: o.id, numero: o.numero };
    },
    sendOS(a) {
      const o = db.os.find(x => x.id === a.id);
      if (!o.tecnicos.length) throw new Error('Escolha pelo menos um técnico');
      if (!db.equips.some(e => e.osId === o.id)) throw new Error('Adicione pelo menos um equipamento/serviço');
      if (o.status !== 'Rascunho') throw new Error('Esta OS já foi enviada');
      o.status = 'Enviada'; o.enviadaEm = now(); salvar(); return { status: o.status };
    },
    deleteOS(a) { db.os = db.os.filter(o => o.id !== a.id); salvar(); return { ok: true }; },
    reviewItems(a) {
      (a.itens || []).forEach(it => {
        const k = it.equipId + '|' + it.itemId;
        const r = db.resp[k] || (db.resp[k] = { k, osId: a.osId, equipId: it.equipId, itemId: it.itemId, valor: '', obs: '', por: '', em: '' });
        r.status = ['APROVADO', 'DEVOLVIDO'].includes(it.status) ? it.status : 'RESPONDIDO'; r.comentario = it.comentario || '';
      });
      salvar(); return { ok: true };
    },
    finishReview(a) {
      const o = db.os.find(x => x.id === a.osId);
      const dv = Object.values(db.resp).filter(r => r.osId === o.id && r.status === 'DEVOLVIDO').length;
      if (!dv && a.aprovarRestantes) detalhe(o).equips.forEach(e => e.itens.forEach(i => { const k = e.id + '|' + i.id; const r = db.resp[k] || (db.resp[k] = { k, osId: o.id, equipId: e.id, itemId: i.id, valor: '', obs: '', comentario: '', por: '', em: '' }); r.status = 'APROVADO'; }));
      o.status = dv ? 'Devolvida' : 'Aprovada'; o.atualizadaEm = now(); o.finalizadaEm = dv ? '' : now();
      salvar(); return { status: o.status, devolvidos: dv };
    },
    listClientes() {
      return db.clientes.map(c => ({ ...c, setores: c.setores.map(s => ({ ...s, checklists: s.checklists.map(k => { const m = db.modelos.find(x => x.id === k.modeloId); return { ...k, modeloNome: m ? m.nome : '', semModelo: !m }; }) })) }));
    },
    saveCliente(a) {
      const c = a.cliente; if (!String(c.nome || '').trim()) throw new Error('Informe o nome do cliente');
      let r = db.clientes.find(x => x.id === c.id);
      const setores = (c.setores || []).filter(s => String(s.nome || '').trim()).map(s => ({ id: s.id || id('S'), nome: s.nome.trim(), checklists: (s.checklists || []).filter(k => k.modeloId).map(k => ({ modeloId: k.modeloId, nome: k.nome || '' })) }));
      if (r) Object.assign(r, { nome: c.nome.trim(), local: c.local, contato: c.contato, telefone: c.telefone, obs: c.obs, setores });
      else { r = { id: id('C'), nome: c.nome.trim(), local: c.local || '', contato: c.contato || '', telefone: c.telefone || '', obs: c.obs || '', setores }; db.clientes.push(r); }
      salvar(); return { id: r.id };
    },
    deleteCliente(a) { db.clientes = db.clientes.filter(c => c.id !== a.id); salvar(); return { ok: true }; },
    reopenOS(a) { const o = db.os.find(x => x.id === a.osId); o.status = 'Em campo'; o.finalizadaEm = ''; salvar(); return { status: o.status }; }
  };
  const GESTOR = ['listClientes', 'saveCliente', 'deleteCliente', 'listUsuarios', 'saveUsuario', 'listModelos', 'saveModelo', 'deleteModelo', 'listOS', 'getOS', 'saveOS', 'sendOS', 'deleteOS', 'reviewItems', 'finishReview', 'reopenOS'];

  window.MockAPI = {
    reset() { localStorage.removeItem(K); seed(); },
    async call(action, token, args) {
      await new Promise(r => setTimeout(r, 120));
      if (!navigator.onLine) { const e = new Error('Failed to fetch'); e.net = true; throw e; }
      try { db = JSON.parse(localStorage.getItem(K)) || db; } catch (e) {}
      const u = db.usuarios.find(x => x.token === token);
      if (!u || !u.ativo) { const e = new Error('ACESSO_NEGADO'); e.server = true; throw e; }
      const fn = A[action];
      try {
        if (!fn) throw new Error('Ação desconhecida: ' + action);
        if (GESTOR.includes(action) && u.perfil !== 'Gestor') throw new Error('Apenas o gestor pode fazer isso');
        return JSON.parse(JSON.stringify(fn(args || {}, u)));
      } catch (e) { e.server = true; throw e; }
    }
  };
})();
