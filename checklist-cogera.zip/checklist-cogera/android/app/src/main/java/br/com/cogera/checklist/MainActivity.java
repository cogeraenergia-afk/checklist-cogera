package br.com.cogera.checklist;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Casca do app: um WebView que abre o app do GitHub Pages.
 * - câmera e galeria para o <input type="file">
 * - GPS para o carimbo das fotos
 * - deep link cogerachecklist://abrir?u=TOKEN (entra já logado)
 * - botão voltar navega dentro do app
 * - tela de "sem internet" quando não há cópia guardada
 */
public class MainActivity extends Activity {

    private static final int REQ_ARQUIVO = 10;
    private static final int REQ_GPS = 11;

    private WebView web;
    private ValueCallback<Uri[]> callbackArquivo;
    private Uri fotoCameraUri;
    private GeolocationPermissions.Callback gpsCallback;
    private String gpsOrigem;
    private String appUrl;
    private String appHost;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appUrl = BuildConfig.APP_URL.endsWith("/") ? BuildConfig.APP_URL : BuildConfig.APP_URL + "/";
        appHost = Uri.parse(appUrl).getHost();

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0b1220"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " ChecklistCogeraApp/" + BuildConfig.VERSION_NAME);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if ("cogerachecklist".equals(scheme)) { abrirDeepLink(u); return true; }
                if (("https".equals(scheme) || "http".equals(scheme)) && appHost != null && appHost.equals(u.getHost())) {
                    // .apk baixa pelo navegador (atualização do app)
                    if (u.getPath() != null && u.getPath().endsWith(".apk")) { abrirFora(u); return true; }
                    return false;
                }
                abrirFora(u); // WhatsApp, Drive, mapas etc.
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) mostrarSemInternet();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (callbackArquivo != null) callbackArquivo.onReceiveValue(null);
                callbackArquivo = cb;
                return abrirSeletor(params);
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, true);
                } else {
                    gpsCallback = callback;
                    gpsOrigem = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GPS);
                }
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> abrirFora(Uri.parse(url)));

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else if (!tratarIntent(getIntent())) web.loadUrl(appUrl + "index.html");
    }

    // ---------- deep link ----------
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        tratarIntent(intent);
    }

    private boolean tratarIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return false;
        Uri u = intent.getData();
        if (!"cogerachecklist".equals(u.getScheme())) return false;
        abrirDeepLink(u);
        return true;
    }

    private void abrirDeepLink(Uri u) {
        String token = u.getQueryParameter("u");
        String url = appUrl + "index.html" + (token != null && !token.isEmpty() ? "?u=" + Uri.encode(token) : "");
        web.loadUrl(url);
    }

    private void abrirFora(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Nenhum app para abrir este link", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- sem internet ----------
    private void mostrarSemInternet() {
        try {
            InputStream in = getAssets().open("offline.html");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            String html = new String(out.toByteArray(), StandardCharsets.UTF_8).replace("{{URL}}", appUrl + "index.html");
            web.loadDataWithBaseURL(appUrl, html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "Sem internet", Toast.LENGTH_LONG).show();
        }
    }

    // ---------- câmera e galeria ----------
    private boolean abrirSeletor(WebChromeClient.FileChooserParams params) {
        Intent camera = null;
        try {
            File pasta = new File(getCacheDir(), "fotos");
            if (!pasta.exists()) pasta.mkdirs();
            File arq = new File(pasta, "foto_" + System.currentTimeMillis() + ".jpg");
            fotoCameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", arq);
            camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, fotoCameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception e) {
            fotoCameraUri = null;
        }

        Intent alvo;
        if (params.isCaptureEnabled() && camera != null) {
            alvo = camera; // botão "Tirar foto" vai direto para a câmera
        } else {
            Intent galeria = new Intent(Intent.ACTION_GET_CONTENT);
            galeria.addCategory(Intent.CATEGORY_OPENABLE);
            galeria.setType("image/*");
            if (params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                galeria.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            alvo = Intent.createChooser(galeria, "Escolher foto");
            if (camera != null) alvo.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
        }
        try {
            startActivityForResult(alvo, REQ_ARQUIVO);
            return true;
        } catch (ActivityNotFoundException e) {
            callbackArquivo = null;
            Toast.makeText(this, "Câmera/galeria indisponível", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_ARQUIVO || callbackArquivo == null) return;
        Uri[] resultado = null;
        if (resultCode == RESULT_OK) {
            ArrayList<Uri> lista = new ArrayList<>();
            if (data != null && data.getClipData() != null) {
                ClipData clip = data.getClipData();
                for (int i = 0; i < clip.getItemCount(); i++) lista.add(clip.getItemAt(i).getUri());
            } else if (data != null && data.getData() != null) {
                lista.add(data.getData());
            } else if (fotoCameraUri != null) {
                lista.add(fotoCameraUri); // foto da câmera
            }
            if (!lista.isEmpty()) resultado = lista.toArray(new Uri[0]);
        }
        callbackArquivo.onReceiveValue(resultado);
        callbackArquivo = null;
    }

    // ---------- permissões ----------
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_GPS && gpsCallback != null) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            gpsCallback.invoke(gpsOrigem, ok, ok);
            gpsCallback = null;
        }
    }

    // ---------- voltar ----------
    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }
}
