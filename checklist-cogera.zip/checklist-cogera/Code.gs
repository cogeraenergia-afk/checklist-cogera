/**
 * CHECKLIST DE CAMPO – COGERA
 * Backend (API JSON) em Google Apps Script.
 *
 * Como usar (resumo – veja o guia completo):
 *  1. Planilha nova > Extensões > Apps Script > cole este arquivo inteiro em Code.gs.
 *  2. Selecione a função "setup" no topo e clique em Executar (autorize).
 *  3. Implantar > Nova implantação > App da Web
 *       Executar como: Eu  ·  Quem pode acessar: Qualquer pessoa
 *  4. Copie a URL que termina em /exec. Ela vai no API_URL.txt.
 *
 * Chamada: POST (Content-Type: text/plain) com corpo JSON
 *   { "action": "nomeDaAcao", "u": "TOKEN", "args": { ... } }
 * Resposta: { "ok": true, "data": ... }  ou  { "ok": false, "error": "mensagem" }
 */

// ===================== INSTALAÇÃO (rodar 1 vez – deixe "setup" selecionado no topo e clique Executar) =====================
function setup() {
  Logger.log('Iniciando setup…');
  var ss = ss_();
  Logger.log('Planilha: ' + ss.getName() + ' – ' + ss.getUrl());
  Object.keys(TABELAS).forEach(function (nome) {
    var sh = ss.getSheetByName(nome) || ss.insertSheet(nome);
    var cab = TABELAS[nome];
    sh.getRange(1, 1, 1, cab.length).setValues([cab]).setFontWeight('bold').setBackground('#259048').setFontColor('#ffffff');
    sh.setFrozenRows(1);
    sh.getRange(1, 1, sh.getMaxRows(), cab.length).setNumberFormat('@'); // tudo como texto
  });
  var padrao = ss.getSheetByName('Página1') || ss.getSheetByName('Sheet1');
  if (padrao && ss.getSheets().length > 1) ss.deleteSheet(padrao);

  var us = ss.getSheetByName('Usuarios');
  us.getRange('C2:C500').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['Técnico', 'Gestor']).build());
  us.getRange('E2:E500').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['SIM', 'NÃO']).build());

  _cache = {};
  pastaRaiz_();
  if (!tab_('Usuarios', true).rows.some(function (u) { return u.Perfil === 'Gestor'; })) {
    tab_('Usuarios', true).append({ ID: proxId_('U'), Nome: 'Leonardo (gestor)', Perfil: 'Gestor', Token: token_(), Ativo: 'SIM', Telefone: '', CriadoEm: agora_() });
  }
  modelosExemplo_();      // só cria os modelos de exemplo que ainda não existem
  clienteExemplo_();

  var g = tab_('Usuarios', true).rows.filter(function (u) { return u.Perfil === 'Gestor'; })[0];
  Logger.log('PRONTO! Seu token de gestor: ' + g.Token);
  Logger.log('Ele também fica na aba Usuarios, coluna Token.');
  Logger.log('Depois de publicar o app, entre por: <link do app>/index.html?u=' + g.Token);
}


// Planilha usada como banco de dados. Funciona com o script criado DENTRO da planilha
// (Extensões › Apps Script) ou solto: nesse caso cria a planilha "Checklist Cogera" sozinho.
function ss_() {
  var a = SpreadsheetApp.getActive();
  if (a) return a;
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SS_ID');
  if (id) { try { return SpreadsheetApp.openById(id); } catch (e) {} }
  var nova = SpreadsheetApp.create('Checklist Cogera');
  props.setProperty('SS_ID', nova.getId());
  Logger.log('O script não estava dentro de uma planilha, então criei uma: ' + nova.getUrl());
  return nova;
}

// ===================== ESTRUTURA DAS ABAS =====================
var TABELAS = {
  Usuarios:    ['ID', 'Nome', 'Perfil', 'Token', 'Ativo', 'Telefone', 'CriadoEm'],
  Modelos:     ['ModeloID', 'Nome', 'Categoria', 'Ativo', 'AtualizadoEm'],
  ModeloItens: ['ItemID', 'ModeloID', 'Etapa', 'OrdemEtapa', 'Ordem', 'Titulo', 'Tipo', 'MinFotos', 'Unidade', 'Obrigatorio', 'Instrucao', 'Par', 'Tag'],
  OS:          ['OSID', 'Numero', 'Cliente', 'Local', 'Data', 'Tecnicos', 'Status', 'Obs', 'CriadaPor', 'CriadaEm', 'AtualizadaEm', 'EnviadaEm', 'FinalizadaEm', 'PastaID', 'ClienteID'],
  OSEquip:     ['EquipID', 'OSID', 'Ordem', 'ModeloID', 'ModeloNome', 'NomeEquip', 'Itens', 'PastaID', 'Setor'],
  Clientes:    ['ClienteID', 'Nome', 'Local', 'Contato', 'Telefone', 'Obs', 'Ativo', 'AtualizadoEm'],
  Setores:     ['SetorID', 'ClienteID', 'Ordem', 'Nome', 'Checklists'],
  Respostas:   ['RespID', 'OSID', 'EquipID', 'ItemID', 'Valor', 'Obs', 'Status', 'Comentario', 'AtualizadoPor', 'AtualizadoEm', 'RevisadoEm'],
  Fotos:       ['FotoID', 'OSID', 'EquipID', 'ItemID', 'Etapa', 'DriveID', 'Nome', 'DataHora', 'Lat', 'Lng', 'Tecnico', 'EnviadaEm', 'Removida'],
  Log:         ['DataHora', 'Usuario', 'Acao', 'Detalhe'],
  Config:      ['Chave', 'Valor']
};

var STATUS = { RASCUNHO: 'Rascunho', ENVIADA: 'Enviada', CAMPO: 'Em campo', VALIDAR: 'Para validar', APROVADA: 'Aprovada', DEVOLVIDA: 'Devolvida' };
var ITEM = { PENDENTE: '', RESPONDIDO: 'RESPONDIDO', APROVADO: 'APROVADO', DEVOLVIDO: 'DEVOLVIDO' };
var TIPOS = ['FOTO', 'OKNOK', 'NUMERO', 'TEXTO', 'OBS', 'ASSINATURA', 'ESCOLHA'];

// ===================== ENTRADA HTTP =====================
function doGet(e) {
  return json_({ ok: true, app: 'checklist-cogera', hora: agora_() });
}

function doPost(e) {
  var req;
  try {
    req = JSON.parse(e.postData.contents);
  } catch (err) {
    return json_({ ok: false, error: 'Requisição inválida' });
  }
  try {
    var user = auth_(req.u);
    var fn = ACOES[req.action];
    if (!fn) throw new Error('Ação desconhecida: ' + req.action);
    if (fn.gestor && user.Perfil !== 'Gestor') throw new Error('Apenas o gestor pode fazer isso');
    var data = fn.run(req.args || {}, user);
    return json_({ ok: true, data: data });
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// ===================== AÇÕES =====================
var ACOES = {
  // ---------- comum ----------
  whoami: { run: function (a, u) {
    return { id: u.ID, nome: u.Nome, perfil: u.Perfil };
  } },

  // ---------- técnico ----------
  myOS: { run: function (a, u) {
    var limite = new Date(Date.now() - 30 * 864e5).toISOString();
    var lista = tab_('OS').rows.filter(function (o) {
      if (lista_(o.Tecnicos).indexOf(String(u.ID)) < 0) return false;
      if ([STATUS.ENVIADA, STATUS.CAMPO, STATUS.DEVOLVIDA, STATUS.VALIDAR].indexOf(o.Status) >= 0) return true;
      return o.Status === STATUS.APROVADA && String(o.FinalizadaEm) > limite;
    });
    return lista.map(function (o) { return detalheOS_(o, false); });
  } },

  saveRespostas: { run: function (a, u) {
    var itens = a.itens || [];
    if (!itens.length) return { salvos: 0 };
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var t = tab_('Respostas', true);
      var osT = tab_('OS', true);
      var tocadas = {};
      var salvos = 0;
      itens.forEach(function (it) {
        var os = osT.find('OSID', it.osId);
        if (!os) return;
        if (u.Perfil !== 'Gestor' && lista_(os.Tecnicos).indexOf(String(u.ID)) < 0) return;
        if ([STATUS.ENVIADA, STATUS.CAMPO, STATUS.DEVOLVIDA].indexOf(os.Status) < 0) return;
        var id = it.equipId + '|' + it.itemId;
        var r = t.find('RespID', id);
        if (r && r.Status === ITEM.APROVADO) return;            // item aprovado fica travado
        if (r && it.ts && String(r.AtualizadoEm) > String(it.ts)) return; // versão mais nova já gravada
        var novo = {
          RespID: id, OSID: it.osId, EquipID: it.equipId, ItemID: it.itemId,
          Valor: it.valor == null ? '' : String(it.valor),
          Obs: it.obs == null ? '' : String(it.obs),
          Status: ITEM.RESPONDIDO,
          Comentario: r ? r.Comentario : '',
          AtualizadoPor: u.Nome, AtualizadoEm: it.ts || agora_(), RevisadoEm: r ? r.RevisadoEm : ''
        };
        if (r) t.update(r, novo); else t.append(novo);
        tocadas[it.osId] = os;
        salvos++;
      });
      Object.keys(tocadas).forEach(function (k) {
        var os = tocadas[k];
        if (os.Status === STATUS.ENVIADA) osT.update(os, { Status: STATUS.CAMPO, AtualizadaEm: agora_() });
      });
      return { salvos: salvos };
    } finally { lock.releaseLock(); }
  } },

  uploadFoto: { run: function (a, u) {
    if (!a.fotoId || !a.b64) throw new Error('Foto inválida');
    var existente = tab_('Fotos').find('FotoID', a.fotoId);
    if (existente) return { fotoId: a.fotoId, driveId: existente.DriveID, repetida: true };

    var os = tab_('OS').find('OSID', a.osId);
    if (!os) throw new Error('OS não encontrada');
    if (u.Perfil !== 'Gestor' && lista_(os.Tecnicos).indexOf(String(u.ID)) < 0) throw new Error('OS não é sua');
    if ([STATUS.ENVIADA, STATUS.CAMPO, STATUS.DEVOLVIDA].indexOf(os.Status) < 0) throw new Error('OS não está aberta para fotos (' + os.Status + ')');
    var eq = tab_('OSEquip').find('EquipID', a.equipId);
    if (!eq) throw new Error('Equipamento não encontrado');
    var item = JSON.parse(eq.Itens || '[]').filter(function (i) { return i.id === a.itemId; })[0];
    if (!item) throw new Error('Item não encontrado');

    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      // confere de novo dentro do lock (reenvio simultâneo)
      var fT = tab_('Fotos', true);
      var dup = fT.find('FotoID', a.fotoId);
      if (dup) return { fotoId: a.fotoId, driveId: dup.DriveID, repetida: true };

      var pasta = pastaEtapa_(os, eq, item);
      var n = fT.rows.filter(function (f) { return f.EquipID === a.equipId && f.ItemID === a.itemId; }).length + 1;
      var nome = slug_(item.titulo) + '_' + ('0' + n).slice(-2) + '.jpg';
      var blob = Utilities.newBlob(Utilities.base64Decode(a.b64), 'image/jpeg', nome);
      var file = pasta.createFile(blob);
      try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
      fT.append({
        FotoID: a.fotoId, OSID: a.osId, EquipID: a.equipId, ItemID: a.itemId, Etapa: item.etapa,
        DriveID: file.getId(), Nome: nome, DataHora: a.dataHora || agora_(),
        Lat: a.lat || '', Lng: a.lng || '', Tecnico: u.Nome, EnviadaEm: agora_(), Removida: ''
      });
      var osT = tab_('OS', true);
      var o2 = osT.find('OSID', a.osId);
      if (o2.Status === STATUS.ENVIADA) osT.update(o2, { Status: STATUS.CAMPO, AtualizadaEm: agora_() });
      return { fotoId: a.fotoId, driveId: file.getId() };
    } finally { lock.releaseLock(); }
  } },

  removeFoto: { run: function (a, u) {
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var fT = tab_('Fotos', true);
      var f = fT.find('FotoID', a.fotoId);
      if (!f) return { removida: false };
      var os = tab_('OS').find('OSID', f.OSID);
      if (u.Perfil !== 'Gestor') {
        if (lista_(os.Tecnicos).indexOf(String(u.ID)) < 0) throw new Error('OS não é sua');
        var r = tab_('Respostas').find('RespID', f.EquipID + '|' + f.ItemID);
        if (r && r.Status === ITEM.APROVADO) throw new Error('Item já aprovado');
      }
      fT.update(f, { Removida: 'SIM' });
      try { DriveApp.getFileById(f.DriveID).setTrashed(true); } catch (e) {}
      return { removida: true };
    } finally { lock.releaseLock(); }
  } },

  submitOS: { run: function (a, u) {
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var osT = tab_('OS', true);
      var os = osT.find('OSID', a.osId);
      if (!os) throw new Error('OS não encontrada');
      if (u.Perfil !== 'Gestor' && lista_(os.Tecnicos).indexOf(String(u.ID)) < 0) throw new Error('OS não é sua');
      if (os.Status === STATUS.VALIDAR) return { status: os.Status };
      if ([STATUS.ENVIADA, STATUS.CAMPO, STATUS.DEVOLVIDA].indexOf(os.Status) < 0) throw new Error('OS está ' + os.Status);
      var faltas = pendencias_(os);
      if (faltas.length) throw new Error('Ainda falta: ' + faltas.slice(0, 5).join('; ') + (faltas.length > 5 ? ' (+' + (faltas.length - 5) + ')' : ''));
      osT.update(os, { Status: STATUS.VALIDAR, AtualizadaEm: agora_() });
      log_(u, 'submitOS', os.Numero);
      return { status: STATUS.VALIDAR };
    } finally { lock.releaseLock(); }
  } },

  getFoto: { run: function (a, u) {
    var f = tab_('Fotos').find('FotoID', a.fotoId) || tab_('Fotos').find('DriveID', a.driveId);
    if (!f) throw new Error('Foto não encontrada');
    if (u.Perfil !== 'Gestor') {
      var os = tab_('OS').find('OSID', f.OSID);
      if (lista_(os.Tecnicos).indexOf(String(u.ID)) < 0) throw new Error('Sem acesso');
    }
    var blob = DriveApp.getFileById(f.DriveID).getBlob();
    return { b64: Utilities.base64Encode(blob.getBytes()), nome: f.Nome };
  } },

  // ---------- gestor: usuários ----------
  listUsuarios: { gestor: true, run: function () {
    return tab_('Usuarios').rows.map(function (r) {
      return { id: r.ID, nome: r.Nome, perfil: r.Perfil, token: r.Token, ativo: ativo_(r.Ativo), telefone: r.Telefone };
    });
  } },

  saveUsuario: { gestor: true, run: function (a, u) {
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var t = tab_('Usuarios', true);
      var r = a.id ? t.find('ID', a.id) : null;
      var dados = {
        Nome: (a.nome || '').trim(), Perfil: a.perfil === 'Gestor' ? 'Gestor' : 'Técnico',
        Ativo: a.ativo === false ? 'NÃO' : 'SIM', Telefone: a.telefone || ''
      };
      if (!dados.Nome) throw new Error('Informe o nome');
      if (r) {
        if (String(r.ID) === String(u.ID) && (dados.Ativo === 'NÃO' || dados.Perfil !== 'Gestor')) throw new Error('Você não pode desativar o seu próprio acesso de gestor');
        if (a.novoToken) dados.Token = token_();
        t.update(r, dados);
        log_(u, 'saveUsuario', dados.Nome);
        return { id: r.ID };
      }
      dados.ID = proxId_('U'); dados.Token = token_(); dados.CriadoEm = agora_();
      t.append(dados);
      log_(u, 'novoUsuario', dados.Nome);
      return { id: dados.ID };
    } finally { lock.releaseLock(); }
  } },

  // ---------- gestor: modelos ----------
  listModelos: { gestor: true, run: function () {
    var itens = tab_('ModeloItens').rows;
    return tab_('Modelos').rows.filter(function (m) { return ativo_(m.Ativo); }).map(function (m) {
      return modeloObj_(m, itens);
    });
  } },

  saveModelo: { gestor: true, run: function (a, u) {
    var m = a.modelo;
    if (!m || !String(m.nome || '').trim()) throw new Error('Informe o nome do modelo');
    if (!m.itens || !m.itens.length) throw new Error('O modelo precisa de pelo menos um item');
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var mt = tab_('Modelos', true);
      var id = m.id;
      var row = id ? mt.find('ModeloID', id) : null;
      if (!row) {
        id = proxId_('M');
        mt.append({ ModeloID: id, Nome: m.nome.trim(), Categoria: m.categoria || '', Ativo: 'SIM', AtualizadoEm: agora_() });
      } else {
        mt.update(row, { Nome: m.nome.trim(), Categoria: m.categoria || '', AtualizadoEm: agora_() });
      }
      var it = tab_('ModeloItens', true);
      it.removeWhere(function (r) { return r.ModeloID === id; });
      var linhas = m.itens.map(function (i, k) {
        if (TIPOS.indexOf(i.tipo) < 0) throw new Error('Tipo inválido: ' + i.tipo);
        return {
          ItemID: i.id || ('I' + Utilities.getUuid().slice(0, 8)), ModeloID: id,
          Etapa: i.etapa || 'Geral', OrdemEtapa: i.ordemEtapa || 1, Ordem: k + 1,
          Titulo: i.titulo, Tipo: i.tipo, MinFotos: i.tipo === 'FOTO' ? Math.max(1, +i.minFotos || 1) : 0,
          Unidade: i.unidade || '', Obrigatorio: i.obrig === false ? 'NÃO' : 'SIM',
          Instrucao: i.instr || '', Par: i.par || '', Tag: i.tag || ''
        };
      });
      it.appendMany(linhas);
      log_(u, 'saveModelo', m.nome);
      return { id: id };
    } finally { lock.releaseLock(); }
  } },

  deleteModelo: { gestor: true, run: function (a, u) {
    var mt = tab_('Modelos', true);
    var r = mt.find('ModeloID', a.id);
    if (r) mt.update(r, { Ativo: 'NÃO', AtualizadoEm: agora_() });
    log_(u, 'deleteModelo', a.id);
    return { ok: true };
  } },

  // ---------- gestor: OS ----------
  listOS: { gestor: true, run: function () {
    var resp = agrupa_(tab_('Respostas').rows, 'OSID');
    var fotos = agrupa_(tab_('Fotos').rows.filter(function (f) { return !f.Removida; }), 'OSID');
    var equips = agrupa_(tab_('OSEquip').rows, 'OSID');
    return tab_('OS').rows.map(function (o) {
      var eqs = equips[o.OSID] || [];
      var total = 0, feitos = 0, aprov = 0, dev = 0;
      var rmap = {}; (resp[o.OSID] || []).forEach(function (r) { rmap[r.RespID] = r; });
      var fmap = {}; (fotos[o.OSID] || []).forEach(function (f) { var k = f.EquipID + '|' + f.ItemID; fmap[k] = (fmap[k] || 0) + 1; });
      eqs.forEach(function (e) {
        JSON.parse(e.Itens || '[]').forEach(function (i) {
          if (!obrigatorio_(i)) return;
          total++;
          var k = e.EquipID + '|' + i.id, r = rmap[k];
          if (completo_(i, r, fmap[k] || 0)) feitos++;
          if (r && r.Status === ITEM.APROVADO) aprov++;
          if (r && r.Status === ITEM.DEVOLVIDO) dev++;
        });
      });
      return {
        id: o.OSID, numero: o.Numero, cliente: o.Cliente, local: o.Local, data: o.Data,
        tecnicos: lista_(o.Tecnicos), status: o.Status, atualizadaEm: o.AtualizadaEm,
        equips: eqs.map(function (e) { return (e.Setor ? e.Setor + ' › ' : '') + e.NomeEquip; }),
        total: total, feitos: feitos, aprovados: aprov, devolvidos: dev, fotos: (fotos[o.OSID] || []).length
      };
    });
  } },

  getOS: { gestor: true, run: function (a) {
    var o = tab_('OS').find('OSID', a.id);
    if (!o) throw new Error('OS não encontrada');
    return detalheOS_(o, true);
  } },

  saveOS: { gestor: true, run: function (a, u) {
    var d = a.os;
    if (!d) throw new Error('Dados da OS ausentes');
    if (!String(d.cliente || '').trim()) throw new Error('Informe o cliente');
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var osT = tab_('OS', true);
      var row = d.id ? osT.find('OSID', d.id) : null;
      var cab = {
        Cliente: d.cliente.trim(), ClienteID: d.clienteId || '', Local: d.local || '', Data: d.data || '',
        Tecnicos: (d.tecnicos || []).join(','), Obs: d.obs || '', AtualizadaEm: agora_()
      };
      var id;
      if (!row) {
        id = proxId_('OS');
        cab.OSID = id; cab.Numero = proxNumero_(); cab.Status = STATUS.RASCUNHO;
        cab.CriadaPor = u.Nome; cab.CriadaEm = agora_();
        osT.append(cab);
        row = osT.find('OSID', id);
      } else {
        id = row.OSID;
        osT.update(row, cab);
      }
      // equipamentos
      var eT = tab_('OSEquip', true);
      var atuais = eT.rows.filter(function (e) { return e.OSID === id; });
      var modelos = {};
      var mItens = tab_('ModeloItens').rows;
      tab_('Modelos').rows.forEach(function (m) { modelos[m.ModeloID] = modeloObj_(m, mItens); });
      var aberta = row.Status === STATUS.RASCUNHO;
      var manter = {};
      (d.equips || []).forEach(function (e, k) {
        if (e.id) {
          var ex = eT.find('EquipID', e.id);
          if (ex) { manter[e.id] = 1; eT.update(ex, { Ordem: k + 1, NomeEquip: e.nome || ex.NomeEquip, Setor: e.setor || '' }); return; }
        }
        var m = modelos[e.modeloId];
        if (!m) throw new Error('Modelo não encontrado para ' + (e.nome || 'equipamento'));
        var nid = proxId_('E');
        manter[nid] = 1;
        eT.append({
          EquipID: nid, OSID: id, Ordem: k + 1, ModeloID: m.id, ModeloNome: m.nome,
          NomeEquip: e.nome || m.nome, Itens: JSON.stringify(m.itens), PastaID: '', Setor: e.setor || ''
        });
      });
      // remoção de equipamentos só quando não houver nada respondido
      var respostas = tab_('Respostas').rows, fotos = tab_('Fotos').rows;
      atuais.forEach(function (e) {
        if (manter[e.EquipID]) return;
        var usado = respostas.some(function (r) { return r.EquipID === e.EquipID; }) ||
                    fotos.some(function (f) { return f.EquipID === e.EquipID && !f.Removida; });
        if (usado && !aberta) throw new Error('Não dá para remover "' + e.NomeEquip + '": já tem respostas/fotos');
      });
      eT.removeWhere(function (e) { return e.OSID === id && !manter[e.EquipID]; });
      log_(u, 'saveOS', row.Numero);
      return { id: id, numero: row.Numero };
    } finally { lock.releaseLock(); }
  } },

  sendOS: { gestor: true, run: function (a, u) {
    var osT = tab_('OS', true);
    var o = osT.find('OSID', a.id);
    if (!o) throw new Error('OS não encontrada');
    if (!lista_(o.Tecnicos).length) throw new Error('Escolha pelo menos um técnico');
    if (!tab_('OSEquip').rows.some(function (e) { return e.OSID === o.OSID; })) throw new Error('Adicione pelo menos um equipamento/serviço');
    if (o.Status !== STATUS.RASCUNHO) throw new Error('Esta OS já foi enviada');
    osT.update(o, { Status: STATUS.ENVIADA, EnviadaEm: agora_(), AtualizadaEm: agora_() });
    log_(u, 'sendOS', o.Numero);
    return { status: STATUS.ENVIADA };
  } },

  deleteOS: { gestor: true, run: function (a, u) {
    var osT = tab_('OS', true);
    var o = osT.find('OSID', a.id);
    if (!o) return { ok: true };
    if (o.Status !== STATUS.RASCUNHO) throw new Error('Só é possível excluir OS em rascunho');
    osT.removeWhere(function (r) { return r.OSID === a.id; });
    tab_('OSEquip', true).removeWhere(function (r) { return r.OSID === a.id; });
    log_(u, 'deleteOS', o.Numero);
    return { ok: true };
  } },

  reviewItems: { gestor: true, run: function (a, u) {
    // a.osId, a.itens: [{equipId, itemId, status:'APROVADO'|'DEVOLVIDO'|'', comentario}]
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var o = tab_('OS').find('OSID', a.osId);
      if (!o) throw new Error('OS não encontrada');
      var t = tab_('Respostas', true);
      (a.itens || []).forEach(function (it) {
        var id = it.equipId + '|' + it.itemId;
        var r = t.find('RespID', id);
        var st = it.status === ITEM.APROVADO || it.status === ITEM.DEVOLVIDO ? it.status : ITEM.RESPONDIDO;
        var dados = { Status: st, Comentario: it.comentario || '', RevisadoEm: agora_() };
        if (r) t.update(r, dados);
        else t.append(Object.assign({ RespID: id, OSID: a.osId, EquipID: it.equipId, ItemID: it.itemId, Valor: '', Obs: '', AtualizadoPor: '', AtualizadoEm: '' }, dados));
      });
      return { ok: true };
    } finally { lock.releaseLock(); }
  } },

  finishReview: { gestor: true, run: function (a, u) {
    var osT = tab_('OS', true);
    var o = osT.find('OSID', a.osId);
    if (!o) throw new Error('OS não encontrada');
    var resp = tab_('Respostas').rows.filter(function (r) { return r.OSID === o.OSID; });
    var dev = resp.filter(function (r) { return r.Status === ITEM.DEVOLVIDO; }).length;
    var novo;
    if (dev) novo = STATUS.DEVOLVIDA;
    else {
      if (a.aprovarRestantes) {
        var t = tab_('Respostas', true);
        detalheOS_(o, false).equips.forEach(function (e) {
          e.itens.forEach(function (i) {
            var id = e.id + '|' + i.id, r = t.find('RespID', id);
            if (r && r.Status === ITEM.APROVADO) return;
            var dados = { Status: ITEM.APROVADO, RevisadoEm: agora_() };
            if (r) t.update(r, dados);
            else t.append(Object.assign({ RespID: id, OSID: o.OSID, EquipID: e.id, ItemID: i.id, Valor: '', Obs: '', Comentario: '', AtualizadoPor: '', AtualizadoEm: '' }, dados));
          });
        });
      }
      novo = STATUS.APROVADA;
    }
    osT.update(o, { Status: novo, AtualizadaEm: agora_(), FinalizadaEm: novo === STATUS.APROVADA ? agora_() : '' });
    log_(u, 'finishReview', o.Numero + ' -> ' + novo);
    return { status: novo, devolvidos: dev };
  } },

  reopenOS: { gestor: true, run: function (a, u) {
    var osT = tab_('OS', true);
    var o = osT.find('OSID', a.osId);
    if (!o) throw new Error('OS não encontrada');
    var novo = a.paraRascunho && o.Status === STATUS.ENVIADA ? STATUS.RASCUNHO : STATUS.CAMPO;
    osT.update(o, { Status: novo, AtualizadaEm: agora_(), FinalizadaEm: '' });
    log_(u, 'reopenOS', o.Numero);
    return { status: novo };
  } },

  // ---------- gestor: clientes e setores ----------
  listClientes: { gestor: true, run: function () {
    var setores = agrupa_(tab_('Setores').rows, 'ClienteID');
    var modelos = {};
    tab_('Modelos').rows.forEach(function (m) { if (ativo_(m.Ativo)) modelos[m.ModeloID] = m.Nome; });
    return tab_('Clientes').rows.filter(function (c) { return ativo_(c.Ativo); }).map(function (c) {
      return {
        id: c.ClienteID, nome: c.Nome, local: c.Local, contato: c.Contato, telefone: c.Telefone, obs: c.Obs,
        setores: (setores[c.ClienteID] || []).sort(function (a, b) { return a.Ordem - b.Ordem; }).map(function (s) {
          return {
            id: s.SetorID, nome: s.Nome,
            checklists: JSON.parse(s.Checklists || '[]').map(function (k) {
              return { modeloId: k.modeloId, nome: k.nome || '', modeloNome: modelos[k.modeloId] || '', semModelo: !modelos[k.modeloId] };
            })
          };
        })
      };
    }).sort(function (a, b) { return a.nome.localeCompare(b.nome); });
  } },

  saveCliente: { gestor: true, run: function (a, u) {
    var c = a.cliente;
    if (!c || !String(c.nome || '').trim()) throw new Error('Informe o nome do cliente');
    var lock = LockService.getScriptLock(); lock.waitLock(30000);
    try {
      var ct = tab_('Clientes', true);
      var row = c.id ? ct.find('ClienteID', c.id) : null;
      var dados = { Nome: c.nome.trim(), Local: c.local || '', Contato: c.contato || '', Telefone: c.telefone || '', Obs: c.obs || '', Ativo: 'SIM', AtualizadoEm: agora_() };
      var id;
      if (row) { id = row.ClienteID; ct.update(row, dados); }
      else { id = proxId_('C'); dados.ClienteID = id; ct.append(dados); }
      var st = tab_('Setores', true);
      st.removeWhere(function (r) { return r.ClienteID === id; });
      st.appendMany((c.setores || []).filter(function (s) { return String(s.nome || '').trim(); }).map(function (s, k) {
        return {
          SetorID: s.id || proxId_('S'), ClienteID: id, Ordem: k + 1, Nome: s.nome.trim(),
          Checklists: JSON.stringify((s.checklists || []).filter(function (x) { return x.modeloId; }).map(function (x) { return { modeloId: x.modeloId, nome: x.nome || '' }; }))
        };
      }));
      log_(u, 'saveCliente', dados.Nome);
      return { id: id };
    } finally { lock.releaseLock(); }
  } },

  deleteCliente: { gestor: true, run: function (a, u) {
    var ct = tab_('Clientes', true);
    var r = ct.find('ClienteID', a.id);
    if (r) ct.update(r, { Ativo: 'NÃO', AtualizadoEm: agora_() });
    log_(u, 'deleteCliente', a.id);
    return { ok: true };
  } },

  getConfig: { gestor: true, run: function () {
    var c = {};
    tab_('Config').rows.forEach(function (r) { c[r.Chave] = r.Valor; });
    return c;
  } },

  setConfig: { gestor: true, run: function (a, u) {
    var t = tab_('Config', true);
    Object.keys(a || {}).forEach(function (k) {
      if (['APP_URL', 'EMPRESA', 'WHATSAPP_MSG'].indexOf(k) < 0) return;
      var r = t.find('Chave', k);
      if (r) t.update(r, { Valor: a[k] }); else t.append({ Chave: k, Valor: a[k] });
    });
    return { ok: true };
  } }
};

// ===================== REGRAS DE NEGÓCIO =====================
function obrigatorio_(i) { return i.tipo !== 'OBS' && i.obrig !== false; }

function completo_(i, r, nFotos) {
  if (i.tipo === 'FOTO') return i.obrig === false || nFotos >= (+i.minFotos || 1);
  if (i.tipo === 'ASSINATURA') return i.obrig === false || nFotos >= 1;
  if (i.tipo === 'OBS') return true;
  if (i.obrig === false) return true;
  if (!r || r.Valor === '' || r.Valor == null) return false;
  if (i.tipo === 'OKNOK' && r.Valor === 'NOK' && !String(r.Obs || '').trim()) return false;
  return true;
}

function pendencias_(os) {
  var d = detalheOS_(os, false);
  var faltas = [];
  d.equips.forEach(function (e) {
    e.itens.forEach(function (i) {
      var r = d.respostas[e.id + '|' + i.id];
      var nf = d.fotos.filter(function (f) { return f.equipId === e.id && f.itemId === i.id; }).length;
      var rr = r ? { Valor: r.valor, Obs: r.obs, Status: r.status } : null;
      if (r && r.status === ITEM.DEVOLVIDO) faltas.push(e.nome + ' › ' + i.titulo + ' (devolvido)');
      else if (!completo_(i, rr, nf)) faltas.push(e.nome + ' › ' + i.titulo);
    });
  });
  return faltas;
}

function detalheOS_(o, completo) {
  var usuarios = {};
  tab_('Usuarios').rows.forEach(function (u) { usuarios[u.ID] = u.Nome; });
  var equips = tab_('OSEquip').rows.filter(function (e) { return e.OSID === o.OSID; })
    .sort(function (a, b) { return a.Ordem - b.Ordem; })
    .map(function (e) {
      return { id: e.EquipID, nome: e.NomeEquip, setor: e.Setor || '', modeloId: e.ModeloID, modeloNome: e.ModeloNome, itens: JSON.parse(e.Itens || '[]') };
    });
  var respostas = {};
  tab_('Respostas').rows.forEach(function (r) {
    if (r.OSID !== o.OSID) return;
    respostas[r.RespID] = { valor: r.Valor, obs: r.Obs, status: r.Status, comentario: r.Comentario, por: r.AtualizadoPor, em: r.AtualizadoEm };
  });
  var fotos = tab_('Fotos').rows.filter(function (f) { return f.OSID === o.OSID && !f.Removida; }).map(function (f) {
    return { id: f.FotoID, equipId: f.EquipID, itemId: f.ItemID, etapa: f.Etapa, driveId: f.DriveID, nome: f.Nome, dataHora: f.DataHora, lat: f.Lat, lng: f.Lng, tecnico: f.Tecnico };
  });
  return {
    id: o.OSID, numero: o.Numero, cliente: o.Cliente, clienteId: o.ClienteID || '', local: o.Local, data: o.Data, obs: o.Obs,
    status: o.Status, tecnicos: lista_(o.Tecnicos),
    tecnicosNomes: lista_(o.Tecnicos).map(function (id) { return usuarios[id] || id; }),
    criadaEm: o.CriadaEm, enviadaEm: o.EnviadaEm, atualizadaEm: o.AtualizadaEm, finalizadaEm: o.FinalizadaEm,
    pastaUrl: completo && o.PastaID ? 'https://drive.google.com/drive/folders/' + o.PastaID : '',
    equips: equips, respostas: respostas, fotos: fotos
  };
}

function modeloObj_(m, itens) {
  return {
    id: m.ModeloID, nome: m.Nome, categoria: m.Categoria, atualizadoEm: m.AtualizadoEm,
    itens: itens.filter(function (i) { return i.ModeloID === m.ModeloID; })
      .sort(function (a, b) { return (a.OrdemEtapa - b.OrdemEtapa) || (a.Ordem - b.Ordem); })
      .map(function (i) {
        return {
          id: i.ItemID, etapa: i.Etapa, ordemEtapa: +i.OrdemEtapa || 1, titulo: i.Titulo, tipo: i.Tipo,
          minFotos: +i.MinFotos || 0, unidade: i.Unidade, obrig: i.Obrigatorio !== 'NÃO',
          instr: i.Instrucao, par: i.Par, tag: i.Tag
        };
      })
  };
}

// ===================== DRIVE =====================
function pastaRaiz_() {
  var id = cfg_('PASTA_RAIZ_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  var p = DriveApp.createFolder('Checklist Cogera - Fotos');
  setCfg_('PASTA_RAIZ_ID', p.getId());
  return p;
}

function pastaEtapa_(os, eq, item) {
  var osT = tab_('OS', true), eT = tab_('OSEquip', true);
  var o = osT.find('OSID', os.OSID), e = eT.find('EquipID', eq.EquipID);
  var pOS = null, pEq = null;
  if (o.PastaID) { try { pOS = DriveApp.getFolderById(o.PastaID); } catch (x) {} }
  if (!pOS) {
    pOS = pastaRaiz_().createFolder(limpa_(o.Numero + ' - ' + o.Cliente + (o.Local ? ' - ' + o.Local : '')));
    osT.update(o, { PastaID: pOS.getId() });
  }
  if (e.PastaID) { try { pEq = DriveApp.getFolderById(e.PastaID); } catch (x) {} }
  if (!pEq) {
    pEq = pOS.createFolder(limpa_(('0' + e.Ordem).slice(-2) + ' - ' + (e.Setor ? e.Setor + ' - ' : '') + e.NomeEquip + (e.NomeEquip !== e.ModeloNome ? ' (' + e.ModeloNome + ')' : '')));
    eT.update(e, { PastaID: pEq.getId() });
  }
  var nomeEtapa = limpa_(item.ordemEtapa + ' - ' + item.etapa);
  var it = pEq.getFoldersByName(nomeEtapa);
  return it.hasNext() ? it.next() : pEq.createFolder(nomeEtapa);
}

// ===================== ACESSO À PLANILHA =====================
var _cache = {};
function tab_(nome, fresh) {
  if (_cache[nome] && !fresh) return _cache[nome];
  var cab = TABELAS[nome];
  var sh = garanteAba_(nome);
  var n = sh.getLastRow();
  var vals = n > 1 ? sh.getRange(2, 1, n - 1, cab.length).getDisplayValues() : [];
  var rows = vals.map(function (v, i) {
    var o = { _row: i + 2 };
    cab.forEach(function (c, k) { o[c] = v[k]; });
    return o;
  }).filter(function (o) { return o[cab[0]] !== ''; });
  var t = {
    rows: rows,
    find: function (col, val) {
      val = String(val);
      for (var i = 0; i < rows.length; i++) if (String(rows[i][col]) === val) return rows[i];
      return null;
    },
    update: function (row, dados) {
      Object.keys(dados).forEach(function (k) {
        var c = cab.indexOf(k);
        if (c < 0) return;
        row[k] = dados[k] == null ? '' : String(dados[k]);
        sh.getRange(row._row, c + 1).setValue(row[k]);
      });
    },
    append: function (dados) {
      var linha = cab.map(function (c) { return dados[c] == null ? '' : String(dados[c]); });
      sh.appendRow(linha);
      var o = { _row: sh.getLastRow() };
      cab.forEach(function (c, k) { o[c] = linha[k]; });
      rows.push(o);
      return o;
    },
    appendMany: function (lista) {
      if (!lista.length) return;
      var m = lista.map(function (d) { return cab.map(function (c) { return d[c] == null ? '' : String(d[c]); }); });
      var ini = sh.getLastRow() + 1;
      sh.getRange(ini, 1, m.length, cab.length).setValues(m);
      _cache[nome] = null;
    },
    removeWhere: function (pred) {
      var alvo = rows.filter(pred).map(function (r) { return r._row; }).sort(function (a, b) { return b - a; });
      alvo.forEach(function (r) { sh.deleteRow(r); });
      _cache[nome] = null;
    }
  };
  _cache[nome] = t;
  return t;
}

// Cria a aba (ou as colunas novas) se ainda não existirem – assim atualizações não exigem rodar o setup.
var _abaOk = {};
function garanteAba_(nome) {
  var ss = ss_();
  var cab = TABELAS[nome];
  var sh = ss.getSheetByName(nome);
  if (sh && _abaOk[nome]) return sh;
  if (!sh) sh = ss.insertSheet(nome);
  if (sh.getLastColumn() < cab.length || sh.getLastRow() === 0) {
    sh.getRange(1, 1, Math.max(sh.getMaxRows(), 2), cab.length).setNumberFormat('@');
    sh.getRange(1, 1, 1, cab.length).setValues([cab]).setFontWeight('bold').setBackground('#259048').setFontColor('#ffffff');
    sh.setFrozenRows(1);
  }
  _abaOk[nome] = true;
  return sh;
}

function auth_(token) {
  if (!token) throw new Error('Sem acesso: abra o app pelo seu link');
  var u = tab_('Usuarios').find('Token', token);
  if (!u || !ativo_(u.Ativo)) throw new Error('ACESSO_NEGADO');
  return u;
}

function cfg_(k) { var r = tab_('Config').find('Chave', k); return r ? r.Valor : ''; }
function setCfg_(k, v) { var t = tab_('Config', true); var r = t.find('Chave', k); if (r) t.update(r, { Valor: v }); else t.append({ Chave: k, Valor: v }); }

function proxNumero_() {
  var n = (+cfg_('SEQ_OS') || 0) + 1;
  setCfg_('SEQ_OS', n);
  return 'OS-' + ('000' + n).slice(-4);
}
function proxId_(p) { return p + Utilities.getUuid().replace(/-/g, '').slice(0, 10); }
function token_() { return Utilities.getUuid().replace(/-/g, '').slice(0, 24); }
function agora_() { return new Date().toISOString(); }
function ativo_(v) { return ['SIM', 'TRUE', 'VERDADEIRO', '1', 'S'].indexOf(String(v).toUpperCase().trim()) >= 0; }
function lista_(s) { return String(s || '').split(',').map(function (x) { return x.trim(); }).filter(String); }
function agrupa_(arr, k) { var o = {}; arr.forEach(function (r) { (o[r[k]] = o[r[k]] || []).push(r); }); return o; }
function slug_(s) { return String(s || 'foto').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'foto'; }
function limpa_(s) { return String(s).replace(/[\\\/:*?"<>|]/g, '-').slice(0, 120); }
function log_(u, acao, det) { try { tab_('Log', true).append({ DataHora: agora_(), Usuario: u.Nome, Acao: acao, Detalhe: det }); } catch (e) {} }

function clienteExemplo_() {
  if (tab_('Clientes', true).rows.length) return;
  var mod = {};
  tab_('Modelos', true).rows.forEach(function (m) { if (ativo_(m.Ativo)) mod[m.Nome] = m.ModeloID; });
  var k = function (nomeModelo, ident) { return mod[nomeModelo] ? { modeloId: mod[nomeModelo], nome: ident } : null; };
  ACOES.saveCliente.run({ cliente: {
    nome: 'Cliente 123 (exemplo)', local: 'Campo Grande - MS',
    setores: [
      { nome: 'Banco de Capacitor', checklists: [k('Banco de capacitores', 'Banco 1')].filter(Boolean) },
      { nome: 'Subestação 1', checklists: [k('Transformador a óleo', 'Trafo 1'), k('Disjuntor', 'Disjuntor geral')].filter(Boolean) },
      { nome: 'Encerramento', checklists: [k('Aceite do cliente', 'Aceite')].filter(Boolean) }
    ]
  } }, { Nome: 'setup', Perfil: 'Gestor' });
}

function modelosExemplo_() {
  var ex = [
    { nome: 'Transformador a óleo', categoria: 'Subestação', itens: [
      ['Antes', 1, 'Vista geral do transformador', 'FOTO', 2, '', 'P1'],
      ['Antes', 1, 'Placa de identificação', 'FOTO', 1, '', '', 'PLACA'],
      ['Antes', 1, 'Nível de óleo', 'OKNOK'],
      ['Antes', 1, 'Vazamentos aparentes', 'OKNOK'],
      ['Testes', 2, 'Coleta de óleo (frasco identificado)', 'FOTO', 2],
      ['Testes', 2, 'Megôhmetro – resistência de isolamento', 'FOTO', 6],
      ['Testes', 2, 'Isolamento AT-massa', 'NUMERO', 0, 'MΩ'],
      ['Testes', 2, 'TTR – relação de transformação', 'FOTO', 5],
      ['Depois', 3, 'Vista geral do transformador', 'FOTO', 2, '', 'P1'],
      ['Depois', 3, 'Observações finais', 'OBS']
    ] },
    { nome: 'Posto de transformação – escopo visual', categoria: 'Rede', itens: [
      ['Antes', 1, 'Vista geral do posto', 'FOTO', 2, '', 'P1'],
      ['Antes', 1, 'Integridade do poste', 'OKNOK'],
      ['Antes', 1, 'Isoladores e para-raios', 'OKNOK'],
      ['Antes', 1, 'Chaves fusíveis', 'FOTO', 1],
      ['Antes', 1, 'Aterramento', 'OKNOK'],
      ['Depois', 2, 'Vista geral do posto', 'FOTO', 2, '', 'P1'],
      ['Depois', 2, 'Observações', 'OBS']
    ] },
    { nome: 'Cabine blindada', categoria: 'Subestação', itens: [
      ['Antes', 1, 'Fachada / porta da cabine', 'FOTO', 1, '', 'P1'],
      ['Antes', 1, 'Interior – limpeza', 'FOTO', 2, '', 'P2'],
      ['Testes', 2, 'Reaperto de conexões', 'OKNOK'],
      ['Testes', 2, 'Termografia', 'FOTO', 2],
      ['Testes', 2, 'Temperatura máxima medida', 'NUMERO', 0, '°C'],
      ['Depois', 3, 'Fachada / porta da cabine', 'FOTO', 1, '', 'P1'],
      ['Depois', 3, 'Interior – limpeza', 'FOTO', 2, '', 'P2']
    ] },
    { nome: 'Disjuntor', categoria: 'Subestação', itens: [
      ['Antes', 1, 'Vista geral do disjuntor', 'FOTO', 1, '', 'P1'],
      ['Antes', 1, 'Placa de identificação', 'FOTO', 1, '', '', 'PLACA'],
      ['Antes', 1, 'Contador de operações', 'NUMERO', 0, 'op.'],
      ['Testes', 2, 'Resistência de contato', 'FOTO', 3],
      ['Testes', 2, 'Maior resistência de contato', 'NUMERO', 0, 'µΩ'],
      ['Testes', 2, 'Abertura e fechamento', 'OKNOK'],
      ['Depois', 3, 'Vista geral do disjuntor', 'FOTO', 1, '', 'P1']
    ] },
    { nome: 'Banco de capacitores', categoria: 'Subestação', itens: [
      ['Antes', 1, 'Vista geral do banco', 'FOTO', 1, '', 'P1'],
      ['Antes', 1, 'Células estufadas ou vazando', 'OKNOK'],
      ['Testes', 2, 'Capacitância das células', 'FOTO', 2],
      ['Testes', 2, 'Fusíveis', 'OKNOK'],
      ['Depois', 3, 'Vista geral do banco', 'FOTO', 1, '', 'P1']
    ] },
    { nome: 'Diário de obra', categoria: 'Obras', itens: [
      // [etapa, ordem, título, tipo, mín. fotos, unidade/opções, par, tag, obrigatório, instrução]
      ['Dados do dia', 1, 'Tempo – manhã', 'ESCOLHA', 0, 'Bom;Nublado;Chuva'],
      ['Dados do dia', 1, 'Tempo – tarde', 'ESCOLHA', 0, 'Bom;Nublado;Chuva'],
      ['Dados do dia', 1, 'Condição de trabalho', 'ESCOLHA', 0, 'Praticável;Parcialmente;Impraticável'],
      ['Dados do dia', 1, 'Horário de início', 'TEXTO', 0, '', '', '', true, 'Ex.: 07:00'],
      ['Dados do dia', 1, 'Horário de término', 'TEXTO', 0, '', '', '', true, 'Ex.: 17:00'],
      ['Equipe', 2, 'Encarregado / responsável na obra', 'TEXTO'],
      ['Equipe', 2, 'Equipe presente (nome e função)', 'TEXTO', 0, '', '', '', true, 'Um por linha. Ex.: João Silva – eletricista'],
      ['Equipe', 2, 'Total de pessoas na obra', 'NUMERO', 0, 'pessoas'],
      ['Equipe', 2, 'Terceiros / visitantes', 'TEXTO', 0, '', '', '', false, 'Empresa, nome e motivo da visita'],
      ['Equipe', 2, 'Foto da equipe / DDS', 'FOTO', 1],
      ['Equipe', 2, 'Uso de EPI conforme', 'OKNOK'],
      ['Atividades', 3, 'Atividades executadas no dia', 'TEXTO', 0, '', '', '', true, 'Descreva o que foi feito e onde'],
      ['Atividades', 3, 'Fotos do andamento', 'FOTO', 4],
      ['Atividades', 3, 'Equipamentos e veículos utilizados', 'TEXTO', 0, '', '', '', false],
      ['Atividades', 3, 'Materiais recebidos / utilizados', 'TEXTO', 0, '', '', '', false],
      ['Ocorrências', 4, 'Houve ocorrência, paralisação ou acidente?', 'ESCOLHA', 0, 'Não;Sim'],
      ['Ocorrências', 4, 'Descrição da ocorrência', 'TEXTO', 0, '', '', '', false, 'Preencha se marcou Sim'],
      ['Ocorrências', 4, 'Fotos da ocorrência', 'FOTO', 1, '', '', '', false],
      ['Encerramento', 5, 'Pendências para o próximo dia', 'OBS'],
      ['Encerramento', 5, 'Assinatura do encarregado', 'ASSINATURA']
    ] },
    { nome: 'Aceite do cliente', categoria: 'Encerramento', itens: [
      ['Encerramento', 1, 'Observações do cliente', 'OBS'],
      ['Encerramento', 1, 'Assinatura do responsável', 'ASSINATURA']
    ] },
    { nome: 'TOF em gerador', categoria: 'Geradores', itens: [
      ['Antes', 1, 'Placa do gerador', 'FOTO', 1, '', '', 'PLACA'],
      ['Antes', 1, 'Horímetro', 'NUMERO', 0, 'h'],
      ['Antes', 1, 'Foto do horímetro', 'FOTO', 1],
      ['Testes', 2, 'Partida em vazio', 'OKNOK'],
      ['Testes', 2, 'Tensão de saída', 'NUMERO', 0, 'V'],
      ['Testes', 2, 'Frequência', 'NUMERO', 0, 'Hz'],
      ['Testes', 2, 'Nível de combustível', 'TEXTO'],
      ['Depois', 3, 'Painel do gerador', 'FOTO', 1],
      ['Depois', 3, 'Observações', 'OBS']
    ] }
  ];
  var fake = { Nome: 'setup', Perfil: 'Gestor' };
  var jaTem = {};
  tab_('Modelos', true).rows.forEach(function (m) { if (ativo_(m.Ativo)) jaTem[m.Nome] = 1; });
  ex = ex.filter(function (m) { return !jaTem[m.nome]; });
  ex.forEach(function (m) {
    ACOES.saveModelo.run({ modelo: {
      nome: m.nome, categoria: m.categoria,
      itens: m.itens.map(function (i) {
        return { etapa: i[0], ordemEtapa: i[1], titulo: i[2], tipo: i[3], minFotos: i[4] || 1, unidade: i[5] || '', par: i[6] || '', tag: i[7] || '', obrig: i[8] === false ? false : i[3] !== 'OBS', instr: i[9] || '' };
      })
    } }, fake);
  });
}
