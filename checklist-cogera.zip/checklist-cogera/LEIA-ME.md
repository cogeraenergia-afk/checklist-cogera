# Checklist de Campo Cogera — guia de instalação

## Como o sistema funciona

Você (gestor) monta os modelos de checklist e as OS num painel no PC. O técnico recebe a OS no celular, preenche item por item com a câmera (mesmo sem sinal) e envia para validação. Você aprova ou devolve item por item. Tudo fica numa planilha do Google e as fotos numa pasta do Drive organizada sozinha — você nunca precisa abri-las.

Status da OS: **Rascunho → Enviada → Em campo → Para validar → Aprovada / Devolvida**.

Pasta das fotos no Drive: `Checklist Cogera - Fotos / OS-0001 - Cliente - Local / 01 - Trafo 1 (Transformador a óleo) / 1 - Antes / Placa_01.jpg`

## Modelo de dados (abas da planilha)

| Aba | Para que serve | Colunas |
|---|---|---|
| Usuarios | Quem acessa | ID, Nome, Perfil (Técnico/Gestor), Token, Ativo (SIM/NÃO), Telefone, CriadoEm |
| Modelos | Equipamentos/serviços da matriz | ModeloID, Nome, Categoria, Ativo, AtualizadoEm |
| ModeloItens | Itens de cada modelo | ItemID, ModeloID, Etapa, OrdemEtapa, Ordem, Titulo, Tipo (FOTO/OKNOK/NUMERO/TEXTO/OBS/ASSINATURA), MinFotos, Unidade, Obrigatorio, Instrucao, Par, Tag |
| OS | Ordens de serviço | OSID, Numero, Cliente, Local, Data, Tecnicos, Status, Obs, CriadaPor, CriadaEm, AtualizadaEm, EnviadaEm, FinalizadaEm, PastaID, ClienteID |
| OSEquip | Equipamentos de cada OS (vários por OS) | EquipID, OSID, Ordem, ModeloID, ModeloNome, NomeEquip, Itens (cópia do modelo em JSON), PastaID, Setor |
| Clientes | Clientes cadastrados | ClienteID, Nome, Local, Contato, Telefone, Obs, Ativo, AtualizadoEm |
| Setores | Escopo pronto de cada cliente | SetorID, ClienteID, Ordem, Nome, Checklists (lista de modelos + identificação, em JSON) |
| Respostas | Resposta de cada item | RespID, OSID, EquipID, ItemID, Valor, Obs, Status (RESPONDIDO/APROVADO/DEVOLVIDO), Comentario, AtualizadoPor, AtualizadoEm, RevisadoEm |
| Fotos | Cada foto enviada | FotoID, OSID, EquipID, ItemID, Etapa, DriveID, Nome, DataHora, Lat, Lng, Tecnico, EnviadaEm, Removida |
| Log | Histórico de ações | DataHora, Usuario, Acao, Detalhe |
| Config | Ajustes internos | Chave, Valor (PASTA_RAIZ_ID, SEQ_OS) |

Pontos de projeto:
- Ao criar a OS, os itens do modelo são **copiados** para ela. Editar o modelo depois não bagunça OS antigas.
- **Par** liga um item do Antes ao mesmo item do Depois: na validação aparecem lado a lado, e o técnico vê a foto do Antes como referência ao tirar a do Depois.
- **Tag = PLACA** marca a foto da placa — já deixa pronto para a leitura por IA no futuro.
- O botão "Dados (.json)" e o `dados.json` dentro do .zip trazem a OS inteira estruturada (equipamento › etapa › item › valor › fotos com caminho do arquivo). É a base para o laudo LaTeX automático depois.

---

## Instalação (faça uma vez só)

### Parte A — Planilha e API (Google)

1. Abra **sheets.new** no navegador (cria uma planilha nova). Dê o nome **Checklist Cogera**.
2. Menu **Extensões › Apps Script**.
3. Apague o que estiver escrito e cole **todo** o conteúdo do arquivo **Code.gs**. Clique no disquete (Salvar).
4. No topo, na caixinha de funções, escolha **setup** e clique em **Executar**.
5. Vai aparecer "Autorização necessária": **Revisar permissões › sua conta › Avançado › Acessar (não seguro) › Permitir**. (É o seu próprio script.)
6. Pegue o seu **token de gestor**: volte na planilha, abra a aba **Usuarios** e copie o código da coluna **Token** (linha "Leonardo (gestor)"). Ele também aparece no "Registro de execução" do Apps Script como "Seu token de gestor: …".
   - Se a aba **Usuarios** não existir, o setup não rodou: confira se a caixinha no topo do Apps Script mostra **setup** (e não doGet/doPost) e clique em Executar de novo. Se aparecer erro em vermelho, copie a mensagem.
7. Clique em **Implantar › Nova implantação**. Na engrenagem, escolha **App da Web**.
   - Executar como: **Eu**
   - Quem pode acessar: **Qualquer pessoa**
8. Clique em **Implantar** e copie a **URL do app da Web** (termina em `/exec`).

Confira o resultado no "Registro de execução" (parte de baixo do Apps Script). Deve aparecer:
- `Iniciando setup…`
- `Planilha: … – https://docs.google.com/…` → é nesta planilha que as abas foram criadas (abra esse link se estiver em dúvida)
- `PRONTO! Seu token de gestor: …`

Na planilha devem existir as abas Usuarios, Modelos, ModeloItens, OS, OSEquip, Respostas, Fotos, Log e Config, com 4 modelos de exemplo (Transformador a óleo, Posto de transformação, Cabine blindada, TOF em gerador).

Se o registro mostrar uma linha vermelha de erro, ou se nada disso aparecer, o setup não rodou até o fim: confira se a caixinha no topo mostra **setup** e execute de novo. Se o erro continuar, copie a mensagem vermelha.

### Parte B — GitHub (site + APK)

9. Entre em **github.com** e clique em **New** (novo repositório). Nome: **checklist-cogera**. Marque **Public**. Clique em **Create repository**.
10. Na página do repositório, clique em **creating a new file** (ou **Add file › Create new file**).
    - No nome do arquivo digite exatamente: `.github/workflows/build.yml`
    - Cole todo o conteúdo do arquivo **build.yml**.
    - Clique em **Commit changes**.
11. **Add file › Create new file** de novo:
    - Nome: `API_URL.txt`
    - Conteúdo: cole a URL `/exec` do passo 8 (só ela, nada mais).
    - **Commit changes**.
12. Vá em **Settings › Pages**. Em **Source**, escolha **GitHub Actions**.
13. Volte ao repositório: **Add file › Upload files**, arraste o arquivo **checklist-cogera.zip** (não descompacte) e clique em **Commit changes**.
14. Clique na aba **Actions**. Aguarde o "Publicar app" ficar verde (uns 3 a 5 minutos). Se ficar vermelho, clique nele e veja a mensagem em português.

Pronto. Seu app fica em: `https://SEU-USUARIO.github.io/checklist-cogera/`

### Parte C — Começar a usar

15. No PC, abra: `https://SEU-USUARIO.github.io/checklist-cogera/index.html?u=SEU_TOKEN_DE_GESTOR` (token do passo 6). Salve nos favoritos — depois do primeiro acesso o navegador lembra.
16. Aba **Técnicos e acessos › Novo usuário**: nome, perfil Técnico, WhatsApp.
17. Clique em **WhatsApp** na linha do técnico. Abre a conversa com o convite pronto. O técnico toca no link → **Baixar app → Instalar → Abrir o app** e já entra conectado.
18. Aba **Modelos de checklist**: ajuste os exemplos ou crie os seus (Equipamento › Etapas › Itens).
19. Aba **Ordens de serviço › Nova OS**: cliente, local, data, técnico(s), adicione um ou vários equipamentos, **Salvar e enviar**.
20. Quando o técnico enviar, a OS aparece em **Para validar**. Aprove ou devolva item por item e clique em **Concluir validação**. Use **Exportar fotos + dados (.zip)** para baixar tudo organizado.

---

## Novidades da versão 2

- **Clientes** (painel do gestor): Cliente › Setores › Checklists. Ex.: *Cliente 123* › *Subestação 1* [Transformador a óleo, Disjuntor] › *Banco de Capacitor* [Banco de capacitores]. Na Nova OS, escolha o cliente e toque no setor (ou em "Todos os setores"): os checklists entram prontos, já com o setor.
- **Assinatura**: novo tipo de item na matriz. O técnico assina com o dedo num quadro branco e informa o nome. A assinatura vira um arquivo .jpg na pasta da OS, com nome, data e número da OS no rodapé. Modelo pronto: "Aceite do cliente".
- **Abas do técnico**: Novas · Andamento · Concluídas. A OS sai de Andamento quando o gestor aprova e fica em Concluídas por 30 dias.

### Como atualizar da versão 1 para a 2

1. Apps Script: apague o código, cole o novo **Code.gs** e salve.
2. **Implantar › Gerenciar implantações › lápis ✎ › Versão: Nova versão › Implantar.** (A URL continua a mesma.)
3. *(Opcional)* Com **setup** selecionado, clique em **Executar**. Ele não apaga nada: só cria os modelos novos (Disjuntor, Banco de capacitores, Aceite do cliente) e o "Cliente 123 (exemplo)". As abas Clientes e Setores são criadas sozinhas de qualquer jeito.
4. GitHub: **Add file › Upload files**, envie o novo **checklist-cogera.zip** (mesmo nome, substitui o antigo) e faça o commit. Aguarde o Actions ficar verde.
5. Os celulares recebem a atualização sozinhos ao abrir o app (não precisa reinstalar o APK).

## Atualizar o sistema depois

- **Mudou só o app (HTML)?** Suba o novo .zip (mesmo nome, substituindo). Os celulares recebem a mudança sozinhos, sem reinstalar.
- **Mudou o Code.gs?** Cole o novo código, salve, depois **Implantar › Gerenciar implantações › lápis (editar) › Versão: Nova versão › Implantar**. Assim a URL continua a mesma.
- **Trocou a URL da API?** Edite o `API_URL.txt` no GitHub (lápis › Commit). O site e o APK são refeitos sozinhos.

## Testar sem planilha

Abra `index.html?mock=1&u=gestor` (painel) ou `index.html?mock=1&u=tec1` (técnico). Usa dados de exemplo guardados só no navegador.

## Bom saber

- **Desativar um técnico**: em Técnicos e acessos, **Desativar** (ou mude Ativo para NÃO na planilha). O acesso cai na hora.
- **Celular perdido**: **Novo link** gera outro token; o link antigo para de funcionar.
- **Sem sinal**: tudo fica guardado no celular e sobe sozinho quando a conexão volta, uma foto por vez. O indicador no topo mostra quantas fotos estão na fila. Peça ao técnico para abrir o app com sinal antes de sair da base (para baixar as OS).
- **Chave do APK**: fica na pasta `android/keystore` dentro do .zip. **Nunca troque esses arquivos** — é ela que permite instalar por cima. Como o repositório é público, quem quiser mais segurança pode guardar a chave em Settings › Secrets (KEYSTORE_B64, KEYSTORE_PASSWORD, KEYSTORE_ALIAS) e apagar a pasta do .zip.
- **Fotos no painel**: são mostradas a partir do Drive. Se alguma não carregar como miniatura, o painel busca pela API automaticamente.
